import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import TabNavigation from '@/components/TabNavigation';
import InputSection from '@/components/input/InputSection';
import OutputSection from '@/components/output/OutputSection';

const HomePage = () => {
  const [activeTab, setActiveTab] = useState<'input' | 'output'>('input');

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        {activeTab === 'input' ? (
          <InputSection />
        ) : (
          <OutputSection />
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;
