import { Ship, HelpCircle, User } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Ship className="h-6 w-6" />
          <h1 className="text-xl font-semibold">Ark Sea Food</h1>
          <span className="text-sm bg-white bg-opacity-20 rounded px-2 py-0.5">Cost Calculator</span>
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-sm hover:underline flex items-center">
            <HelpCircle className="h-4 w-4 mr-1" /> Help
          </button>
          <button className="text-sm hover:underline flex items-center">
            <User className="h-4 w-4 mr-1" /> Admin
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
