import { Edit, Calculator } from 'lucide-react';

interface TabNavigationProps {
  activeTab: 'input' | 'output';
  setActiveTab: (tab: 'input' | 'output') => void;
}

const TabNavigation = ({ activeTab, setActiveTab }: TabNavigationProps) => {
  return (
    <div className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4">
        <div className="flex">
          <button 
            className={`px-4 py-3 font-medium focus:outline-none ${
              activeTab === 'input' 
                ? 'text-primary border-b-2 border-primary' 
                : 'text-gray-600 border-b-2 border-transparent hover:text-primary'
            }`}
            onClick={() => setActiveTab('input')}
          >
            <Edit className="h-4 w-4 inline mr-1" /> Input Variables
          </button>
          <button 
            className={`px-4 py-3 font-medium focus:outline-none ${
              activeTab === 'output' 
                ? 'text-primary border-b-2 border-primary' 
                : 'text-gray-600 border-b-2 border-transparent hover:text-primary'
            }`}
            onClick={() => setActiveTab('output')}
          >
            <Calculator className="h-4 w-4 inline mr-1" /> Calculate Costs
          </button>
        </div>
      </div>
    </div>
  );
};

export default TabNavigation;
