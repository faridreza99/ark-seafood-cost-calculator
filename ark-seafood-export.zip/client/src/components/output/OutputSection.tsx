import ProductSelectionForm from './ProductSelectionForm';
import CostResultsCard from './CostResultsCard';
import CostHistoryChart from './CostHistoryChart';
import useCostCalculation from '@/hooks/useCostCalculation';

const OutputSection = () => {
  const {
    productType, 
    setProductType,
    glazingPercentage, 
    setGlazingPercentage,
    size, 
    setSize,
    calculationResult,
    isCalculating,
    error
  } = useCostCalculation();
  
  return (
    <section className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4 text-gray-800 flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
          Product Cost Calculator
        </h2>
        
        <ProductSelectionForm 
          productType={productType}
          setProductType={setProductType}
          glazingPercentage={glazingPercentage}
          setGlazingPercentage={setGlazingPercentage}
          size={size}
          setSize={setSize}
        />
        
        {error ? (
          <div className="bg-red-50 p-4 rounded-md mt-6">
            <p className="text-red-500">{error}</p>
          </div>
        ) : (
          <CostResultsCard 
            result={calculationResult}
            isLoading={isCalculating}
          />
        )}
      </div>
      
      <CostHistoryChart />
    </section>
  );
};

export default OutputSection;
