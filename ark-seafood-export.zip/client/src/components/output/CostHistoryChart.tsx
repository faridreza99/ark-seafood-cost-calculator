import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { LineChart, Download } from 'lucide-react';

// Mock data for demonstration purposes
const mockData = [
  { date: 'Mar 15', costBDT: 32500, costUSD: 295 },
  { date: 'Mar 22', costBDT: 33200, costUSD: 302 },
  { date: 'Mar 29', costBDT: 33800, costUSD: 308 },
  { date: 'Apr 5', costBDT: 34200, costUSD: 311 },
  { date: 'Apr 12', costBDT: 34000, costUSD: 309 },
  { date: 'Apr 19', costBDT: 33600, costUSD: 305 },
];

const CostHistoryChart = () => {
  const [timeRange, setTimeRange] = useState('30');
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between mb-4">
          <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
            <LineChart className="mr-2 h-5 w-5 text-primary" /> Cost History
          </CardTitle>
          <div className="flex space-x-2">
            <Select
              value={timeRange}
              onValueChange={setTimeRange}
            >
              <SelectTrigger className="text-sm py-1 px-2 border rounded focus:ring-1 focus:ring-primary focus:border-primary h-8">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 3 Months</SelectItem>
                <SelectItem value="180">Last 6 Months</SelectItem>
                <SelectItem value="365">This Year</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="secondary" size="sm" className="h-8">
              <Download className="h-3.5 w-3.5 mr-1" /> Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {/* Check if we have real data, if not show placeholder */}
          {mockData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={mockData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis yAxisId="left" orientation="left" stroke="#106ebe" />
                <YAxis yAxisId="right" orientation="right" stroke="#0078d4" />
                <Tooltip />
                <Bar yAxisId="left" dataKey="costBDT" name="Cost (BDT)" fill="#106ebe" />
                <Bar yAxisId="right" dataKey="costUSD" name="Cost (USD)" fill="#0078d4" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full bg-neutral-light rounded flex items-center justify-center">
              <div className="text-gray-500 text-center">
                <LineChart className="mx-auto mb-2 h-10 w-10" />
                <p>No cost history data available</p>
                <p className="text-sm">Calculate costs to build history</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CostHistoryChart;
