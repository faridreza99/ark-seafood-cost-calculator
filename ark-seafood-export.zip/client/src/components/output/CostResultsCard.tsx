import { PrinterIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

// Types
interface CostCalculationResult {
  productType: string;
  size: string;
  glazingPercentage: number;
  rawMaterialCost: number;
  waterCost: number;
  totalOverheads: number;
  freightCost: number;
  subsidyAmount: number;
  netCostBDT: number;
  netCostUSD: number;
  netProductWeight: string;
  piecesPerUnit: string;
  waterWeight: string;
  headLoss: string;
  shellLoss: string;
  soakingGain: string;
}

interface CostResultsCardProps {
  result: CostCalculationResult | null;
  isLoading: boolean;
}

// Format number as currency
const formatCurrency = (value: number, currency: string) => {
  return currency === 'BDT' 
    ? `Tk ${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    : `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const CostResultsCard = ({ result, isLoading }: CostResultsCardProps) => {
  const handlePrintReport = () => {
    window.print();
  };
  
  return (
    <div className="bg-neutral-light p-5 rounded-md mt-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-gray-600 font-medium mb-3">Cost Breakdown</h3>
          <div className="space-y-2">
            {isLoading ? (
              Array(6).fill(0).map((_, i) => (
                <div key={i} className="flex justify-between items-center">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-20" />
                </div>
              ))
            ) : !result ? (
              <div className="text-center py-4 text-gray-500">
                Select options above to calculate costs
              </div>
            ) : (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600">Raw Material Cost:</span>
                  <span className="font-mono">{formatCurrency(result.rawMaterialCost, 'BDT')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Water Cost:</span>
                  <span className="font-mono">{formatCurrency(result.waterCost, 'BDT')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Overheads:</span>
                  <span className="font-mono">{formatCurrency(result.totalOverheads, 'BDT')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Freight Cost:</span>
                  <span className="font-mono">{formatCurrency(result.freightCost, 'BDT')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Subsidy:</span>
                  <span className="font-mono">{formatCurrency(result.subsidyAmount, 'BDT')}</span>
                </div>
                <div className="h-px bg-gray-300 my-2"></div>
                <div className="flex justify-between font-medium">
                  <span>Net Cost (BDT):</span>
                  <span className="font-mono text-lg">{formatCurrency(result.netCostBDT, 'BDT')}</span>
                </div>
                <div className="flex justify-between font-medium text-primary">
                  <span>Net Cost (USD):</span>
                  <span className="font-mono text-lg">{formatCurrency(result.netCostUSD, 'USD')}</span>
                </div>
              </>
            )}
          </div>
        </div>
        
        <div>
          <h3 className="text-gray-600 font-medium mb-3">Product Details</h3>
          <div className="space-y-2">
            {isLoading ? (
              Array(6).fill(0).map((_, i) => (
                <div key={i} className="flex justify-between items-center">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))
            ) : !result ? (
              <div className="text-center py-4 text-gray-500">
                Product details will appear here
              </div>
            ) : (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600">Net Product Weight:</span>
                  <span>{result.netProductWeight}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Pieces Per KG/LB:</span>
                  <span>{result.piecesPerUnit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Water Weight:</span>
                  <span>{result.waterWeight}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Head Loss:</span>
                  <span>{result.headLoss}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shell Loss:</span>
                  <span>{result.shellLoss}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Soaking Gain:</span>
                  <span>{result.soakingGain}</span>
                </div>
              </>
            )}
          </div>
          
          <div className="mt-4">
            <Button
              className="bg-primary hover:bg-secondary text-white py-2 px-4 rounded-md font-medium w-full flex items-center justify-center"
              onClick={handlePrintReport}
              disabled={isLoading || !result}
            >
              <PrinterIcon className="mr-2 h-5 w-5" /> Print Cost Report
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CostResultsCard;
