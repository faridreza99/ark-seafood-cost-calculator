import { useQuery } from '@tanstack/react-query';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { GLAZING_PERCENTAGES } from '@/lib/constants';

// Define types
interface ProductType {
  id: number;
  name: string;
  code: string;
}

interface Size {
  id: number;
  productTypeId: number;
  sizeRange: string;
}

interface ProductSelectionFormProps {
  productType: string;
  setProductType: (value: string) => void;
  glazingPercentage: number;
  setGlazingPercentage: (value: number) => void;
  size: string;
  setSize: (value: string) => void;
}

const ProductSelectionForm = ({
  productType,
  setProductType,
  glazingPercentage,
  setGlazingPercentage,
  size,
  setSize
}: ProductSelectionFormProps) => {
  // Fetch product types
  const { data: productTypes, isLoading: loadingProductTypes } = useQuery<ProductType[]>({
    queryKey: ['/api/product-types'],
  });
  
  // Find selected product type ID
  const selectedProductTypeId = productTypes?.find(pt => pt.code === productType)?.id;
  
  // Fetch sizes based on selected product type
  const { data: sizes, isLoading: loadingSizes } = useQuery<Size[]>({
    queryKey: ['/api/sizes', selectedProductTypeId],
    enabled: !!selectedProductTypeId,
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div className="flex flex-col">
        <Label className="text-gray-600 mb-1">Product Type:</Label>
        <Select
          value={productType}
          onValueChange={setProductType}
          disabled={loadingProductTypes}
        >
          <SelectTrigger className="py-2 px-3 border rounded focus:ring-1 focus:ring-primary focus:border-primary">
            <SelectValue placeholder="Select product type" />
          </SelectTrigger>
          <SelectContent>
            {productTypes?.map(pt => (
              <SelectItem key={pt.id} value={pt.code}>
                {pt.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex flex-col">
        <Label className="text-gray-600 mb-1">Glazing Percentage:</Label>
        <Select
          value={glazingPercentage.toString()}
          onValueChange={(value) => setGlazingPercentage(Number(value))}
        >
          <SelectTrigger className="py-2 px-3 border rounded focus:ring-1 focus:ring-primary focus:border-primary">
            <SelectValue placeholder="Select glazing percentage" />
          </SelectTrigger>
          <SelectContent>
            {GLAZING_PERCENTAGES.map(option => (
              <SelectItem key={option.value} value={option.value.toString()}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex flex-col">
        <Label className="text-gray-600 mb-1">Size:</Label>
        <Select
          value={size}
          onValueChange={setSize}
          disabled={loadingSizes || !selectedProductTypeId}
        >
          <SelectTrigger className="py-2 px-3 border rounded focus:ring-1 focus:ring-primary focus:border-primary">
            <SelectValue placeholder="Select size" />
          </SelectTrigger>
          <SelectContent>
            {sizes?.map(s => (
              <SelectItem key={s.id} value={s.sizeRange}>
                {s.sizeRange}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default ProductSelectionForm;