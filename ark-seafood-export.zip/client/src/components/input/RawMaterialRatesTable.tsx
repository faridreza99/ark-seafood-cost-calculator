import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Tag, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { formatDate } from '@/lib/utils';

interface RawMaterialRate {
  id: number;
  rawMaterialSize: string;
  ratePerKg: number;
  lastUpdated: string;
}

interface RawMaterialRatesTableProps {
  onDataChange: () => void;
}

const RawMaterialRatesTable = ({ onDataChange }: RawMaterialRatesTableProps) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // State for dialog and form
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newSize, setNewSize] = useState('');
  const [newRate, setNewRate] = useState('');
  
  // State for edited rates
  const [editedRates, setEditedRates] = useState<Record<number, number>>({});
  
  // Fetch raw material rates
  const { data: rawMaterialRates, isLoading, error } = useQuery<RawMaterialRate[]>({
    queryKey: ['/api/raw-material-rates'],
  });
  
  // Update rate mutation
  const updateRateMutation = useMutation({
    mutationFn: async ({ id, rate }: { id: number, rate: number }) => {
      const res = await apiRequest('PUT', `/api/raw-material-rates/${id}`, {
        rawMaterialSize: rawMaterialRates?.find(r => r.id === id)?.rawMaterialSize,
        ratePerKg: rate.toString() // Convert to string
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/raw-material-rates'] });
      setEditedRates({});
      onDataChange();
    },
    onError: (error) => {
      toast({
        title: "Failed to update rate",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    }
  });
  
  // Add new rate mutation
  const addRateMutation = useMutation({
    mutationFn: async ({ size, rate }: { size: string, rate: number }) => {
      const res = await apiRequest('POST', '/api/raw-material-rates', {
        rawMaterialSize: size,
        ratePerKg: rate.toString() // Convert number to string
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/raw-material-rates'] });
      setIsAddDialogOpen(false);
      setNewSize('');
      setNewRate('');
      onDataChange();
      
      toast({
        title: "Raw material added",
        description: "New raw material rate has been added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add new rate",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    }
  });
  
  // Update rate in local state
  const handleRateChange = (id: number, rate: string) => {
    const numericRate = Number(rate);
    if (!isNaN(numericRate) && numericRate > 0) {
      setEditedRates(prev => ({
        ...prev,
        [id]: numericRate
      }));
      onDataChange();
    }
  };
  
  // Save edited rate on blur
  const handleBlur = (id: number) => {
    if (editedRates[id] !== undefined) {
      updateRateMutation.mutate({ id, rate: editedRates[id] });
    }
  };
  
  // Handle adding new raw material
  const handleAddRawMaterial = () => {
    const numericRate = Number(newRate);
    if (newSize.trim() === '' || isNaN(numericRate) || numericRate <= 0) {
      toast({
        title: "Invalid input",
        description: "Please enter a valid size and rate",
        variant: "destructive",
      });
      return;
    }
    
    addRateMutation.mutate({ size: newSize, rate: numericRate });
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <Tag className="mr-2 h-5 w-5 text-primary" /> Raw Material Rates
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-light">
              <TableRow>
                <TableHead>Raw Material Size</TableHead>
                <TableHead>Rate (Tk/KG)</TableHead>
                <TableHead>Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-4">Loading...</TableCell>
                </TableRow>
              ) : error ? (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-4 text-red-500">
                    Failed to load raw material rates
                  </TableCell>
                </TableRow>
              ) : rawMaterialRates?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-4">
                    No raw material rates found
                  </TableCell>
                </TableRow>
              ) : (
                rawMaterialRates?.map((rate) => (
                  <TableRow key={rate.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <TableCell className="font-medium">{rate.rawMaterialSize}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className="text-gray-500 mr-2">Tk</span>
                        <Input
                          type="number"
                          value={editedRates[rate.id] !== undefined ? editedRates[rate.id] : rate.ratePerKg}
                          onChange={(e) => handleRateChange(rate.id, e.target.value)}
                          onBlur={() => handleBlur(rate.id)}
                          className="w-24 py-1 px-2"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-500 text-sm">
                      {formatDate(new Date(rate.lastUpdated))}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        <div className="mt-3 flex justify-end">
          <Button
            className="bg-primary hover:bg-secondary text-white py-1 px-3 rounded text-sm flex items-center"
            onClick={() => setIsAddDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-1" /> Add Raw Material
          </Button>
        </div>
        
        {/* Add Raw Material Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Raw Material</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="size" className="text-right">
                  Size
                </Label>
                <Input
                  id="size"
                  value={newSize}
                  onChange={(e) => setNewSize(e.target.value)}
                  className="col-span-3"
                  placeholder="e.g., 6"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="rate" className="text-right">
                  Rate (Tk/KG)
                </Label>
                <Input
                  id="rate"
                  type="number"
                  value={newRate}
                  onChange={(e) => setNewRate(e.target.value)}
                  className="col-span-3"
                  placeholder="e.g., 1500"
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsAddDialogOpen(false)}
                disabled={addRateMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                onClick={handleAddRawMaterial}
                disabled={addRateMutation.isPending}
              >
                {addRateMutation.isPending ? "Adding..." : "Add"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default RawMaterialRatesTable;
