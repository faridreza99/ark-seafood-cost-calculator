import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Truck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface FreightCostCardProps {
  onDataChange: () => void;
}

const FreightCostCard = ({ onDataChange }: FreightCostCardProps) => {
  const queryClient = useQueryClient();
  const [freightCost, setFreightCost] = useState<string>('');
  
  // Fetch current settings
  const { data: settings, isLoading } = useQuery<{
    id: number;
    freightCost: number;
    lastUpdated: string;
  }>({
    queryKey: ['/api/settings'],
    onSuccess: (data) => {
      if (data) {
        setFreightCost(data.freightCost.toString());
      }
    }
  });
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: any) => {
      const res = await apiRequest('POST', '/api/settings', updatedSettings);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    }
  });
  
  // Track if there are unsaved changes
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  useEffect(() => {
    if (settings) {
      const costChanged = freightCost !== settings.freightCost.toString();
      setHasUnsavedChanges(costChanged);
    }
  }, [freightCost, settings]);
  
  const handleCostChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFreightCost(e.target.value);
    onDataChange();
  };
  
  const handleBlur = () => {
    if (hasUnsavedChanges && settings) {
      const numericCost = Number(freightCost);
      
      if (!isNaN(numericCost) && numericCost >= 0) {
        updateSettingsMutation.mutate({
          ...settings,
          freightCost: numericCost.toString()
        });
      }
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <Truck className="mr-2 h-5 w-5 text-primary" /> Freight Cost
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <Label className="text-gray-600">Freight Cost:</Label>
          <div className="flex items-center">
            <span className="text-gray-500 mr-2">Tk</span>
            <Input
              type="number"
              value={freightCost}
              onChange={handleCostChange}
              onBlur={handleBlur}
              disabled={isLoading}
              className="w-24 py-2 px-3"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FreightCostCard;
