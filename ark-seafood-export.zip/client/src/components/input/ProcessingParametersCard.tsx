import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Settings } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface ProcessingParametersCardProps {
  onDataChange: () => void;
}

const ProcessingParametersCard = ({ onDataChange }: ProcessingParametersCardProps) => {
  const queryClient = useQueryClient();
  const [headLoss, setHeadLoss] = useState<string>('');
  const [shellLoss, setShellLoss] = useState<string>('');
  const [soakingGain, setSoakingGain] = useState<string>('');
  
  // Fetch current settings
  const { data: settings, isLoading } = useQuery<{
    id: number;
    headLossPercentage: number;
    shellLossPercentage: number;
    soakingGainPercentage: number;
    lastUpdated: string;
  }>({
    queryKey: ['/api/settings'],
    onSuccess: (data) => {
      if (data) {
        setHeadLoss(data.headLossPercentage.toString());
        setShellLoss(data.shellLossPercentage.toString());
        setSoakingGain(data.soakingGainPercentage.toString());
      }
    }
  });
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: any) => {
      const res = await apiRequest('POST', '/api/settings', updatedSettings);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    }
  });
  
  // Track if there are unsaved changes
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  useEffect(() => {
    if (settings) {
      const headChanged = headLoss !== settings.headLossPercentage.toString();
      const shellChanged = shellLoss !== settings.shellLossPercentage.toString();
      const soakingChanged = soakingGain !== settings.soakingGainPercentage.toString();
      setHasUnsavedChanges(headChanged || shellChanged || soakingChanged);
    }
  }, [headLoss, shellLoss, soakingGain, settings]);
  
  const handleHeadLossChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setHeadLoss(e.target.value);
    onDataChange();
  };
  
  const handleShellLossChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setShellLoss(e.target.value);
    onDataChange();
  };
  
  const handleSoakingGainChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSoakingGain(e.target.value);
    onDataChange();
  };
  
  const handleBlur = () => {
    if (hasUnsavedChanges && settings) {
      const numericHead = Number(headLoss);
      const numericShell = Number(shellLoss);
      const numericSoaking = Number(soakingGain);
      
      if (!isNaN(numericHead) && !isNaN(numericShell) && !isNaN(numericSoaking) && 
          numericHead >= 0 && numericShell >= 0 && numericSoaking >= 0) {
        updateSettingsMutation.mutate({
          ...settings,
          headLossPercentage: numericHead.toString(),
          shellLossPercentage: numericShell.toString(),
          soakingGainPercentage: numericSoaking.toString()
        });
      }
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <Settings className="mr-2 h-5 w-5 text-primary" /> Processing Parameters
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col">
            <Label className="text-gray-600 mb-1">Head Loss Percentage:</Label>
            <div className="flex items-center">
              <Input
                type="number"
                value={headLoss}
                onChange={handleHeadLossChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-20 py-2 px-3"
              />
              <span className="text-gray-500 ml-2">%</span>
            </div>
          </div>
          <div className="flex flex-col">
            <Label className="text-gray-600 mb-1">Shell Loss Percentage:</Label>
            <div className="flex items-center">
              <Input
                type="number"
                value={shellLoss}
                onChange={handleShellLossChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-20 py-2 px-3"
              />
              <span className="text-gray-500 ml-2">%</span>
            </div>
          </div>
          <div className="flex flex-col">
            <Label className="text-gray-600 mb-1">Soaking Gain Percentage:</Label>
            <div className="flex items-center">
              <Input
                type="number"
                value={soakingGain}
                onChange={handleSoakingGainChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-20 py-2 px-3"
              />
              <span className="text-gray-500 ml-2">%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProcessingParametersCard;
