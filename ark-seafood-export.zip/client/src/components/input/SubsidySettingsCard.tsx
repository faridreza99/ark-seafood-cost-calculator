import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Landmark } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface SubsidySettingsCardProps {
  onDataChange: () => void;
}

const SubsidySettingsCard = ({ onDataChange }: SubsidySettingsCardProps) => {
  const queryClient = useQueryClient();
  const [subsidyRate, setSubsidyRate] = useState<string>('');
  const [subsidyCap, setSubsidyCap] = useState<string>('');
  
  // Fetch current settings
  const { data: settings, isLoading } = useQuery<{
    id: number;
    subsidyRate: number;
    subsidyCap: number;
    lastUpdated: string;
  }>({
    queryKey: ['/api/settings'],
    onSuccess: (data) => {
      if (data) {
        setSubsidyRate(data.subsidyRate.toString());
        setSubsidyCap(data.subsidyCap.toString());
      }
    }
  });
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: any) => {
      const res = await apiRequest('POST', '/api/settings', updatedSettings);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    }
  });
  
  // Track if there are unsaved changes
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  useEffect(() => {
    if (settings) {
      const rateChanged = subsidyRate !== settings.subsidyRate.toString();
      const capChanged = subsidyCap !== settings.subsidyCap.toString();
      setHasUnsavedChanges(rateChanged || capChanged);
    }
  }, [subsidyRate, subsidyCap, settings]);
  
  const handleRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSubsidyRate(e.target.value);
    onDataChange();
  };
  
  const handleCapChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSubsidyCap(e.target.value);
    onDataChange();
  };
  
  const handleBlur = () => {
    if (hasUnsavedChanges && settings) {
      const numericRate = Number(subsidyRate);
      const numericCap = Number(subsidyCap);
      
      if (!isNaN(numericRate) && !isNaN(numericCap) && numericRate >= 0 && numericCap >= 0) {
        updateSettingsMutation.mutate({
          ...settings,
          subsidyRate: numericRate.toString(),
          subsidyCap: numericCap.toString()
        });
      }
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <Landmark className="mr-2 h-5 w-5 text-primary" /> Subsidy Settings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-gray-600">Subsidy Rate:</Label>
            <div className="flex items-center">
              <Input
                type="number"
                value={subsidyRate}
                onChange={handleRateChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-20 py-2 px-3"
              />
              <span className="text-gray-500 ml-2">%</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <Label className="text-gray-600">Subsidy Cap:</Label>
            <div className="flex items-center">
              <span className="text-gray-500 mr-2">Tk</span>
              <Input
                type="number"
                value={subsidyCap}
                onChange={handleCapChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-24 py-2 px-3"
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubsidySettingsCard;
