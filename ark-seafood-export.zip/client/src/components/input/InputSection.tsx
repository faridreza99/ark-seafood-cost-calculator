import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import RawMaterialRatesTable from './RawMaterialRatesTable';
import ConversionRateCard from './ConversionRateCard';
import SubsidySettingsCard from './SubsidySettingsCard';
import OverheadsCard from './OverheadsCard';
import FreightCostCard from './FreightCostCard';
import ProcessingParametersCard from './ProcessingParametersCard';

const InputSection = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State to track if any changes have been made
  const [hasChanges, setHasChanges] = useState(false);
  
  // Handler to be passed to child components to indicate changes
  const handleChange = () => {
    setHasChanges(true);
  };
  
  // Save all changes mutation
  const saveChangesMutation = useMutation({
    mutationFn: async () => {
      // This would typically save all changes in one go
      // For now, we're just simulating success
      return { success: true };
    },
    onSuccess: () => {
      // Reset change indicator
      setHasChanges(false);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/raw-material-rates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/usd-conversion-rate'] });
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      
      // Show success toast
      toast({
        title: "Changes saved",
        description: "All changes have been saved successfully.",
        duration: 3000,
      });
    },
    onError: (error) => {
      toast({
        title: "Error saving changes",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  const handleSaveChanges = () => {
    saveChangesMutation.mutate();
  };
  
  return (
    <section className="space-y-6">
      <RawMaterialRatesTable onDataChange={handleChange} />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ConversionRateCard onDataChange={handleChange} />
        <SubsidySettingsCard onDataChange={handleChange} />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <OverheadsCard onDataChange={handleChange} />
        <FreightCostCard onDataChange={handleChange} />
      </div>
      
      <ProcessingParametersCard onDataChange={handleChange} />
      
      <div className="flex justify-end mt-6">
        <Button 
          className="bg-success hover:bg-green-700 text-white"
          onClick={handleSaveChanges}
          disabled={!hasChanges || saveChangesMutation.isPending}
        >
          {saveChangesMutation.isPending ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Saving...
            </span>
          ) : (
            <span className="flex items-center">
              <Check className="mr-2 h-5 w-5" /> Save All Changes
            </span>
          )}
        </Button>
      </div>
    </section>
  );
};

export default InputSection;
