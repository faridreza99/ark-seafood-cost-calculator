import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { formatDate } from '@/lib/utils';

interface ConversionRateProps {
  onDataChange: () => void;
}

const ConversionRateCard = ({ onDataChange }: ConversionRateProps) => {
  const queryClient = useQueryClient();
  const [rate, setRate] = useState<string>('');
  
  // Fetch current conversion rate
  const { data: conversionRate, isLoading } = useQuery<{
    id: number;
    rate: number;
    lastUpdated: string;
  }>({
    queryKey: ['/api/usd-conversion-rate'],
    onSuccess: (data) => {
      if (data && !rate) {
        setRate(data.rate.toString());
      }
    }
  });
  
  // Update conversion rate mutation
  const updateRateMutation = useMutation({
    mutationFn: async (newRate: number) => {
      const res = await apiRequest('POST', '/api/usd-conversion-rate', {
        rate: newRate.toString() // Convert to string
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/usd-conversion-rate'] });
    }
  });
  
  const handleRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRate(e.target.value);
    onDataChange();
  };
  
  const handleBlur = () => {
    const numericRate = Number(rate);
    if (!isNaN(numericRate) && numericRate > 0 && numericRate !== conversionRate?.rate) {
      updateRateMutation.mutate(numericRate);
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <DollarSign className="mr-2 h-5 w-5 text-primary" /> USD Conversion Rate
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-4">
          <span className="text-gray-600">1 USD =</span>
          <div className="flex items-center">
            <span className="text-gray-500 mr-2">Tk</span>
            <Input
              type="number"
              value={rate}
              onChange={handleRateChange}
              onBlur={handleBlur}
              disabled={isLoading}
              className="w-24 py-2 px-3"
            />
          </div>
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Last updated: {conversionRate 
            ? formatDate(new Date(conversionRate.lastUpdated)) 
            : 'Loading...'}
        </p>
      </CardContent>
    </Card>
  );
};

export default ConversionRateCard;
