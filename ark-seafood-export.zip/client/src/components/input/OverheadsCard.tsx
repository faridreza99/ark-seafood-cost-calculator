import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { BarChart2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface OverheadsCardProps {
  onDataChange: () => void;
}

const OverheadsCard = ({ onDataChange }: OverheadsCardProps) => {
  const queryClient = useQueryClient();
  const [fixedOverhead, setFixedOverhead] = useState<string>('');
  const [variableOverhead, setVariableOverhead] = useState<string>('');
  
  // Fetch current settings
  const { data: settings, isLoading } = useQuery<{
    id: number;
    fixedOverhead: number;
    variableOverhead: number;
    lastUpdated: string;
  }>({
    queryKey: ['/api/settings'],
    onSuccess: (data) => {
      if (data) {
        setFixedOverhead(data.fixedOverhead.toString());
        setVariableOverhead(data.variableOverhead.toString());
      }
    }
  });
  
  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: any) => {
      const res = await apiRequest('POST', '/api/settings', updatedSettings);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    }
  });
  
  // Track if there are unsaved changes
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  useEffect(() => {
    if (settings) {
      const fixedChanged = fixedOverhead !== settings.fixedOverhead.toString();
      const variableChanged = variableOverhead !== settings.variableOverhead.toString();
      setHasUnsavedChanges(fixedChanged || variableChanged);
    }
  }, [fixedOverhead, variableOverhead, settings]);
  
  const handleFixedChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFixedOverhead(e.target.value);
    onDataChange();
  };
  
  const handleVariableChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVariableOverhead(e.target.value);
    onDataChange();
  };
  
  const handleBlur = () => {
    if (hasUnsavedChanges && settings) {
      const numericFixed = Number(fixedOverhead);
      const numericVariable = Number(variableOverhead);
      
      if (!isNaN(numericFixed) && !isNaN(numericVariable) && numericFixed >= 0 && numericVariable >= 0) {
        updateSettingsMutation.mutate({
          ...settings,
          fixedOverhead: numericFixed.toString(),
          variableOverhead: numericVariable.toString()
        });
      }
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center">
          <BarChart2 className="mr-2 h-5 w-5 text-primary" /> Overhead Costs
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-gray-600">Fixed Overhead:</Label>
            <div className="flex items-center">
              <span className="text-gray-500 mr-2">Tk</span>
              <Input
                type="number"
                value={fixedOverhead}
                onChange={handleFixedChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-24 py-2 px-3"
              />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <Label className="text-gray-600">Variable Overhead:</Label>
            <div className="flex items-center">
              <span className="text-gray-500 mr-2">Tk</span>
              <Input
                type="number"
                value={variableOverhead}
                onChange={handleVariableChange}
                onBlur={handleBlur}
                disabled={isLoading}
                className="w-24 py-2 px-3"
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OverheadsCard;
