import { useState, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

// Define our result type
interface CostCalculationResult {
  productType: string;
  size: string;
  glazingPercentage: number;
  rawMaterialCost: number;
  waterCost: number;
  totalOverheads: number;
  freightCost: number;
  subsidyAmount: number;
  netCostBDT: number;
  netCostUSD: number;
  netProductWeight: string;
  piecesPerUnit: string;
  waterWeight: string;
  headLoss: string;
  shellLoss: string;
  soakingGain: string;
}

const useCostCalculation = () => {
  // Form state
  const [productType, setProductType] = useState<string>('bt_ho_siqf');
  const [glazingPercentage, setGlazingPercentage] = useState<number>(100);
  const [size, setSize] = useState<string>('2/4');
  
  // Result state
  const [calculationResult, setCalculationResult] = useState<CostCalculationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Cost calculation mutation
  const calculateCostMutation = useMutation<CostCalculationResult, Error, { productType: string, glazingPercentage: number, size: string }>({
    mutationFn: async (data) => {
      const res = await apiRequest('POST', '/api/calculate-cost', data);
      return res.json();
    },
    onSuccess: (data) => {
      setCalculationResult(data);
      setError(null);
    },
    onError: (error) => {
      setError(error.message || 'Failed to calculate cost');
      setCalculationResult(null);
    }
  });
  
  // Calculate cost whenever inputs change
  useEffect(() => {
    if (productType && size) {
      calculateCostMutation.mutate({
        productType,
        glazingPercentage,
        size
      });
    }
  }, [productType, glazingPercentage, size]);
  
  return {
    // Input values
    productType,
    setProductType,
    glazingPercentage,
    setGlazingPercentage,
    size,
    setSize,
    
    // Calculation result
    calculationResult,
    isCalculating: calculateCostMutation.isPending,
    error
  };
};

export default useCostCalculation;
