// Product Types
export const PRODUCT_TYPES = [
  { id: 1, name: 'BT HO SIQF', code: 'bt_ho_siqf', description: 'Black Tiger Head On Semi IQF' },
  { id: 2, name: 'BT HLSO IQF', code: 'bt_hlso_iqf', description: 'Black Tiger Headless Shell On IQF' },
  { id: 3, name: 'BT Raw PND', code: 'bt_raw_pnd', description: 'Black Tiger Raw Peeled & Deveined' }
];

// Glazing Percentages
export const GLAZING_PERCENTAGES = [
  { value: 100, label: '100%' },
  { value: 80, label: '80%' },
  { value: 75, label: '75%' },
  { value: 50, label: '50%' },
  { value: 35, label: '35%' },
  { value: 20, label: '20%' }
];

// Sizes
export const SIZES = [
  { id: 1, sizeRange: '2/4', piecesPerUnit: '2-4', unitType: 'KG' },
  { id: 2, sizeRange: '4/6', piecesPerUnit: '4-6', unitType: 'KG' },
  { id: 3, sizeRange: '6/8', piecesPerUnit: '6-8', unitType: 'KG' },
  { id: 4, sizeRange: '8/12', piecesPerUnit: '8-12', unitType: 'KG' },
  { id: 5, sizeRange: '16/20', piecesPerUnit: '16-20', unitType: 'KG' }
];

// Default Settings
export const DEFAULT_SETTINGS = {
  subsidyRate: 4,
  subsidyCap: 50000,
  fixedOverhead: 15000,
  variableOverhead: 8500,
  freightCost: 12500,
  headLossPercentage: 35,
  shellLossPercentage: 15,
  soakingGainPercentage: 8,
  waterWeightPercentage: 25
};
