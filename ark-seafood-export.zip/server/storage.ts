import {
  User,
  InsertUser,
  ProductType,
  InsertProductType,
  Size,
  InsertSize,
  RawMaterialRate,
  InsertRawMaterialRate,
  UsdConversionRate,
  InsertUsdConversionRate,
  Settings,
  InsertSettings,
  CostResult,
  InsertCostResult,
} from "@shared/schema";

export interface IStorage {
  // User methods (kept from original)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product Type methods
  getProductTypes(): Promise<ProductType[]>;
  getProductType(id: number): Promise<ProductType | undefined>;
  getProductTypeByCode(code: string): Promise<ProductType | undefined>;
  createProductType(productType: InsertProductType): Promise<ProductType>;

  // Size methods
  getSizes(): Promise<Size[]>;
  getSizesByProductType(productTypeId: number): Promise<Size[]>;
  getSize(id: number): Promise<Size | undefined>;
  createSize(size: InsertSize): Promise<Size>;

  // Raw Material Rate methods
  getRawMaterialRates(): Promise<RawMaterialRate[]>;
  getRawMaterialRate(id: number): Promise<RawMaterialRate | undefined>;
  createRawMaterialRate(rate: InsertRawMaterialRate): Promise<RawMaterialRate>;
  updateRawMaterialRate(id: number, rate: InsertRawMaterialRate): Promise<RawMaterialRate>;

  // USD Conversion Rate methods
  getLatestUsdConversionRate(): Promise<UsdConversionRate | undefined>;
  createUsdConversionRate(rate: InsertUsdConversionRate): Promise<UsdConversionRate>;

  // Settings methods
  getSettings(): Promise<Settings | undefined>;
  createSettings(settings: InsertSettings): Promise<Settings>;
  updateSettings(id: number, settings: InsertSettings): Promise<Settings>;

  // Cost Result methods
  getCostResults(): Promise<CostResult[]>;
  createCostResult(result: InsertCostResult): Promise<CostResult>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private productTypes: Map<number, ProductType>;
  private sizes: Map<number, Size>;
  private rawMaterialRates: Map<number, RawMaterialRate>;
  private usdConversionRates: Map<number, UsdConversionRate>;
  private settingsData: Map<number, Settings>;
  private costResults: Map<number, CostResult>;
  
  private userCurrentId: number;
  private productTypeCurrentId: number;
  private sizeCurrentId: number;
  private rawMaterialRateCurrentId: number;
  private usdConversionRateCurrentId: number;
  private settingsCurrentId: number;
  private costResultCurrentId: number;

  constructor() {
    this.users = new Map();
    this.productTypes = new Map();
    this.sizes = new Map();
    this.rawMaterialRates = new Map();
    this.usdConversionRates = new Map();
    this.settingsData = new Map();
    this.costResults = new Map();
    
    this.userCurrentId = 1;
    this.productTypeCurrentId = 1;
    this.sizeCurrentId = 1;
    this.rawMaterialRateCurrentId = 1;
    this.usdConversionRateCurrentId = 1;
    this.settingsCurrentId = 1;
    this.costResultCurrentId = 1;
    
    // Initialize with default data
    this.initializeDefaultData();
  }

  // Initialize default data for the application
  private initializeDefaultData() {
    // Create default product types
    const productTypes = [
      { name: 'BT HO SIQF', code: 'bt_ho_siqf', description: 'Black Tiger Head On Semi IQF' },
      { name: 'BT HLSO IQF', code: 'bt_hlso_iqf', description: 'Black Tiger Headless Shell On IQF' },
      { name: 'BT Raw PND', code: 'bt_raw_pnd', description: 'Black Tiger Raw Peeled & Deveined' }
    ];
    
    productTypes.forEach(pt => this.createProductType(pt));
    
    // Create default sizes
    const sizes = [
      { productTypeId: 1, sizeRange: '2/4', piecesPerUnit: '2-4', unitType: 'KG' },
      { productTypeId: 1, sizeRange: '4/6', piecesPerUnit: '4-6', unitType: 'KG' },
      { productTypeId: 1, sizeRange: '6/8', piecesPerUnit: '6-8', unitType: 'KG' },
      { productTypeId: 1, sizeRange: '8/12', piecesPerUnit: '8-12', unitType: 'KG' },
      { productTypeId: 1, sizeRange: '16/20', piecesPerUnit: '16-20', unitType: 'KG' },
      
      { productTypeId: 2, sizeRange: '2/4', piecesPerUnit: '2-4', unitType: 'LB' },
      { productTypeId: 2, sizeRange: '4/6', piecesPerUnit: '4-6', unitType: 'LB' },
      { productTypeId: 2, sizeRange: '6/8', piecesPerUnit: '6-8', unitType: 'LB' },
      { productTypeId: 2, sizeRange: '8/12', piecesPerUnit: '8-12', unitType: 'LB' },
      { productTypeId: 2, sizeRange: '16/20', piecesPerUnit: '16-20', unitType: 'LB' },
      
      { productTypeId: 3, sizeRange: '2/4', piecesPerUnit: '2-4', unitType: 'LB' },
      { productTypeId: 3, sizeRange: '4/6', piecesPerUnit: '4-6', unitType: 'LB' },
      { productTypeId: 3, sizeRange: '6/8', piecesPerUnit: '6-8', unitType: 'LB' },
      { productTypeId: 3, sizeRange: '8/12', piecesPerUnit: '8-12', unitType: 'LB' },
      { productTypeId: 3, sizeRange: '16/20', piecesPerUnit: '16-20', unitType: 'LB' }
    ];
    
    sizes.forEach(size => this.createSize(size));
    
    // Create default raw material rates
    const rawMaterialRates = [
      { rawMaterialSize: '3', ratePerKg: '1950' },
      { rawMaterialSize: '4', ratePerKg: '1850' },
      { rawMaterialSize: '5', ratePerKg: '1750' }
    ];
    
    rawMaterialRates.forEach(rate => this.createRawMaterialRate(rate));
    
    // Create default USD conversion rate
    this.createUsdConversionRate({ rate: '110.25' });
    
    // Create default settings
    this.createSettings({
      subsidyRate: '4',
      subsidyCap: '50000',
      fixedOverhead: '15000',
      variableOverhead: '8500',
      freightCost: '12500',
      headLossPercentage: '35',
      shellLossPercentage: '15',
      soakingGainPercentage: '8',
      waterWeightPercentage: '25'
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Product Type methods
  async getProductTypes(): Promise<ProductType[]> {
    return Array.from(this.productTypes.values());
  }

  async getProductType(id: number): Promise<ProductType | undefined> {
    return this.productTypes.get(id);
  }

  async getProductTypeByCode(code: string): Promise<ProductType | undefined> {
    return Array.from(this.productTypes.values()).find(
      (pt) => pt.code === code,
    );
  }

  async createProductType(insertProductType: InsertProductType): Promise<ProductType> {
    const id = this.productTypeCurrentId++;
    const productType: ProductType = { ...insertProductType, id };
    this.productTypes.set(id, productType);
    return productType;
  }

  // Size methods
  async getSizes(): Promise<Size[]> {
    return Array.from(this.sizes.values());
  }

  async getSizesByProductType(productTypeId: number): Promise<Size[]> {
    return Array.from(this.sizes.values()).filter(
      (size) => size.productTypeId === productTypeId,
    );
  }

  async getSize(id: number): Promise<Size | undefined> {
    return this.sizes.get(id);
  }

  async createSize(insertSize: InsertSize): Promise<Size> {
    const id = this.sizeCurrentId++;
    const size: Size = { ...insertSize, id };
    this.sizes.set(id, size);
    return size;
  }

  // Raw Material Rate methods
  async getRawMaterialRates(): Promise<RawMaterialRate[]> {
    return Array.from(this.rawMaterialRates.values());
  }

  async getRawMaterialRate(id: number): Promise<RawMaterialRate | undefined> {
    return this.rawMaterialRates.get(id);
  }

  async createRawMaterialRate(insertRate: InsertRawMaterialRate): Promise<RawMaterialRate> {
    const id = this.rawMaterialRateCurrentId++;
    const rate: RawMaterialRate = { 
      ...insertRate, 
      id, 
      lastUpdated: new Date()
    };
    this.rawMaterialRates.set(id, rate);
    return rate;
  }

  async updateRawMaterialRate(id: number, insertRate: InsertRawMaterialRate): Promise<RawMaterialRate> {
    const existingRate = await this.getRawMaterialRate(id);
    if (!existingRate) {
      throw new Error(`Raw material rate with id ${id} not found`);
    }
    
    const updatedRate: RawMaterialRate = { 
      ...existingRate, 
      ...insertRate, 
      lastUpdated: new Date()
    };
    
    this.rawMaterialRates.set(id, updatedRate);
    return updatedRate;
  }

  // USD Conversion Rate methods
  async getLatestUsdConversionRate(): Promise<UsdConversionRate | undefined> {
    // Return the most recently updated conversion rate
    const rates = Array.from(this.usdConversionRates.values());
    if (rates.length === 0) return undefined;
    
    return rates.reduce((latest, current) => {
      return latest.lastUpdated > current.lastUpdated ? latest : current;
    });
  }

  async createUsdConversionRate(insertRate: InsertUsdConversionRate): Promise<UsdConversionRate> {
    const id = this.usdConversionRateCurrentId++;
    const rate: UsdConversionRate = { 
      ...insertRate, 
      id, 
      lastUpdated: new Date()
    };
    this.usdConversionRates.set(id, rate);
    return rate;
  }

  // Settings methods
  async getSettings(): Promise<Settings | undefined> {
    // Return the most recent settings
    const allSettings = Array.from(this.settingsData.values());
    if (allSettings.length === 0) return undefined;
    
    return allSettings.reduce((latest, current) => {
      return latest.lastUpdated > current.lastUpdated ? latest : current;
    });
  }

  async createSettings(insertSettings: InsertSettings): Promise<Settings> {
    const id = this.settingsCurrentId++;
    const settings: Settings = { 
      ...insertSettings, 
      id, 
      lastUpdated: new Date()
    };
    this.settingsData.set(id, settings);
    return settings;
  }

  async updateSettings(id: number, insertSettings: InsertSettings): Promise<Settings> {
    const existingSettings = await this.getSettings();
    if (!existingSettings) {
      return this.createSettings(insertSettings);
    }
    
    const updatedSettings: Settings = { 
      ...existingSettings, 
      ...insertSettings, 
      lastUpdated: new Date()
    };
    
    this.settingsData.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }

  // Cost Result methods
  async getCostResults(): Promise<CostResult[]> {
    return Array.from(this.costResults.values());
  }

  async createCostResult(insertResult: InsertCostResult): Promise<CostResult> {
    const id = this.costResultCurrentId++;
    const result: CostResult = { 
      ...insertResult, 
      id, 
      calculationDate: new Date()
    };
    this.costResults.set(id, result);
    return result;
  }
}

export const storage = new MemStorage();
