import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertRawMaterialRateSchema, 
  insertUsdConversionRateSchema, 
  insertSettingsSchema,
  costCalculationInputSchema
} from "@shared/schema";
import { ZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all product types
  app.get("/api/product-types", async (req, res) => {
    try {
      const productTypes = await storage.getProductTypes();
      res.json(productTypes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product types" });
    }
  });

  // Get sizes by product type
  app.get("/api/sizes", async (req, res) => {
    try {
      const productTypeId = req.query.productTypeId ? parseInt(req.query.productTypeId as string) : undefined;
      
      if (productTypeId) {
        const sizes = await storage.getSizesByProductType(productTypeId);
        res.json(sizes);
      } else {
        const sizes = await storage.getSizes();
        res.json(sizes);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sizes" });
    }
  });

  // Get all raw material rates
  app.get("/api/raw-material-rates", async (req, res) => {
    try {
      const rates = await storage.getRawMaterialRates();
      res.json(rates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch raw material rates" });
    }
  });

  // Update raw material rate
  app.put("/api/raw-material-rates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const data = insertRawMaterialRateSchema.parse(req.body);
      const updatedRate = await storage.updateRawMaterialRate(id, data);
      res.json(updatedRate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update raw material rate" });
      }
    }
  });

  // Create new raw material rate
  app.post("/api/raw-material-rates", async (req, res) => {
    try {
      const data = insertRawMaterialRateSchema.parse(req.body);
      const newRate = await storage.createRawMaterialRate(data);
      res.status(201).json(newRate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create raw material rate" });
      }
    }
  });

  // Get latest USD conversion rate
  app.get("/api/usd-conversion-rate", async (req, res) => {
    try {
      const rate = await storage.getLatestUsdConversionRate();
      if (!rate) {
        res.status(404).json({ message: "USD conversion rate not found" });
        return;
      }
      res.json(rate);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch USD conversion rate" });
    }
  });

  // Update USD conversion rate
  app.post("/api/usd-conversion-rate", async (req, res) => {
    try {
      const data = insertUsdConversionRateSchema.parse(req.body);
      const newRate = await storage.createUsdConversionRate(data);
      res.status(201).json(newRate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update USD conversion rate" });
      }
    }
  });

  // Get current settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      if (!settings) {
        res.status(404).json({ message: "Settings not found" });
        return;
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Update settings
  app.post("/api/settings", async (req, res) => {
    try {
      const data = insertSettingsSchema.parse(req.body);
      const settings = await storage.getSettings();
      
      let updatedSettings;
      if (settings) {
        updatedSettings = await storage.updateSettings(settings.id, data);
      } else {
        updatedSettings = await storage.createSettings(data);
      }
      
      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  // Calculate cost
  app.post("/api/calculate-cost", async (req, res) => {
    try {
      const input = costCalculationInputSchema.parse(req.body);
      
      // Get required data for calculation
      const settings = await storage.getSettings();
      const usdRate = await storage.getLatestUsdConversionRate();
      const productType = await storage.getProductTypeByCode(input.productType);
      const rawMaterialRates = await storage.getRawMaterialRates();
      
      if (!settings || !usdRate || !productType) {
        res.status(400).json({ 
          message: "Missing required data", 
          details: {
            settings: !!settings,
            usdRate: !!usdRate,
            productType: !!productType
          }
        });
        return;
      }
      
      // Get product type ID
      const productTypeId = productType.id;
      
      // Find size by product type and size range
      const sizes = await storage.getSizesByProductType(productTypeId);
      const size = sizes.find(s => s.sizeRange === input.size);
      
      if (!size) {
        res.status(400).json({ message: "Invalid size for the selected product type" });
        return;
      }

      // Basic calculation logic - this would be more complex in a real implementation
      // For demonstration, we're using a simplified version
      
      // Raw material cost based on the first rate in the list (would be more specific in reality)
      const rawMaterialRate = rawMaterialRates[0];
      const rawMaterialCost = Number(rawMaterialRate.ratePerKg);
      
      // Calculate water cost (25% of raw material)
      const waterWeight = Number(settings.waterWeightPercentage);
      const waterCost = (rawMaterialCost * waterWeight) / 100;
      
      // Total overheads
      const overheadCost = Number(settings.fixedOverhead) + Number(settings.variableOverhead);
      
      // Freight cost
      const freightCost = Number(settings.freightCost);
      
      // Subsidy calculation (4% of total cost, capped at subsidy cap)
      const totalBeforeSubsidy = rawMaterialCost + waterCost + overheadCost + freightCost;
      const calculatedSubsidy = (totalBeforeSubsidy * Number(settings.subsidyRate)) / 100;
      const subsidyAmount = Math.min(calculatedSubsidy, Number(settings.subsidyCap));
      
      // Final cost in BDT
      const totalCostBDT = totalBeforeSubsidy - subsidyAmount;
      
      // Convert to USD
      const totalCostUSD = totalCostBDT / Number(usdRate.rate);
      
      // Create cost result record
      const costResult = await storage.createCostResult({
        productTypeId,
        sizeId: size.id,
        glazingPercentage: String(input.glazingPercentage),
        rawMaterialCost: String(rawMaterialCost),
        waterCost: String(waterCost),
        overheadCost: String(overheadCost),
        freightCost: String(freightCost),
        subsidyAmount: String(subsidyAmount),
        totalCostBDT: String(totalCostBDT),
        totalCostUSD: String(totalCostUSD)
      });
      
      // Return the calculation result
      res.json({
        productType: productType.name,
        size: size.sizeRange,
        glazingPercentage: input.glazingPercentage,
        rawMaterialCost,
        waterCost,
        totalOverheads: overheadCost,
        freightCost,
        subsidyAmount,
        netCostBDT: totalCostBDT,
        netCostUSD: totalCostUSD,
        netProductWeight: size.unitType === 'KG' ? '750 GM' : '800 GM', // Placeholder - would be calculated based on actual formulas
        piecesPerUnit: `${size.piecesPerUnit} pcs/${size.unitType}`,
        waterWeight: `${waterWeight}%`,
        headLoss: `${settings.headLossPercentage}%`,
        shellLoss: `${settings.shellLossPercentage}%`,
        soakingGain: `${settings.soakingGainPercentage}%`
      });
    } catch (error) {
      console.error(error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to calculate cost" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
