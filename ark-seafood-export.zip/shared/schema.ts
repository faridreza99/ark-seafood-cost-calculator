import { pgTable, text, serial, integer, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model (kept from the original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Product Types table
export const productTypes = pgTable("product_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  description: text("description"),
});

export const insertProductTypeSchema = createInsertSchema(productTypes).pick({
  name: true,
  code: true,
  description: true,
});

export type InsertProductType = z.infer<typeof insertProductTypeSchema>;
export type ProductType = typeof productTypes.$inferSelect;

// Sizes table
export const sizes = pgTable("sizes", {
  id: serial("id").primaryKey(),
  productTypeId: integer("product_type_id").notNull(),
  sizeRange: text("size_range").notNull(),
  piecesPerUnit: text("pieces_per_unit").notNull(),
  unitType: text("unit_type").notNull(), // KG or LB
});

export const insertSizeSchema = createInsertSchema(sizes).pick({
  productTypeId: true,
  sizeRange: true,
  piecesPerUnit: true,
  unitType: true,
});

export type InsertSize = z.infer<typeof insertSizeSchema>;
export type Size = typeof sizes.$inferSelect;

// Raw Material Rates table
export const rawMaterialRates = pgTable("raw_material_rates", {
  id: serial("id").primaryKey(),
  rawMaterialSize: text("raw_material_size").notNull(),
  ratePerKg: decimal("rate_per_kg", { precision: 10, scale: 2 }).notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertRawMaterialRateSchema = createInsertSchema(rawMaterialRates)
  .pick({
    rawMaterialSize: true,
    ratePerKg: true,
  })
  .transform((data) => ({
    ...data,
    ratePerKg: typeof data.ratePerKg === 'number' ? String(data.ratePerKg) : data.ratePerKg,
  }));

export type InsertRawMaterialRate = z.infer<typeof insertRawMaterialRateSchema>;
export type RawMaterialRate = typeof rawMaterialRates.$inferSelect;

// USD Conversion Rate table
export const usdConversionRates = pgTable("usd_conversion_rates", {
  id: serial("id").primaryKey(),
  rate: decimal("rate", { precision: 10, scale: 2 }).notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertUsdConversionRateSchema = createInsertSchema(usdConversionRates)
  .pick({
    rate: true,
  })
  .transform((data) => ({
    ...data,
    rate: typeof data.rate === 'number' ? String(data.rate) : data.rate,
  }));

export type InsertUsdConversionRate = z.infer<typeof insertUsdConversionRateSchema>;
export type UsdConversionRate = typeof usdConversionRates.$inferSelect;

// Settings table (for subsidies, overheads, etc.)
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  subsidyRate: decimal("subsidy_rate", { precision: 10, scale: 2 }).notNull(),
  subsidyCap: decimal("subsidy_cap", { precision: 10, scale: 2 }).notNull(),
  fixedOverhead: decimal("fixed_overhead", { precision: 10, scale: 2 }).notNull(),
  variableOverhead: decimal("variable_overhead", { precision: 10, scale: 2 }).notNull(),
  freightCost: decimal("freight_cost", { precision: 10, scale: 2 }).notNull(),
  headLossPercentage: decimal("head_loss_percentage", { precision: 10, scale: 2 }).notNull(),
  shellLossPercentage: decimal("shell_loss_percentage", { precision: 10, scale: 2 }).notNull(),
  soakingGainPercentage: decimal("soaking_gain_percentage", { precision: 10, scale: 2 }).notNull(),
  waterWeightPercentage: decimal("water_weight_percentage", { precision: 10, scale: 2 }).notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertSettingsSchema = createInsertSchema(settings)
  .pick({
    subsidyRate: true,
    subsidyCap: true,
    fixedOverhead: true,
    variableOverhead: true,
    freightCost: true,
    headLossPercentage: true,
    shellLossPercentage: true,
    soakingGainPercentage: true,
    waterWeightPercentage: true,
  })
  .transform((data) => {
    return Object.entries(data).reduce((acc, [key, value]) => {
      return {
        ...acc,
        [key]: typeof value === 'number' ? String(value) : value
      };
    }, {});
  });

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

// Cost Calculation Results
export const costResults = pgTable("cost_results", {
  id: serial("id").primaryKey(),
  productTypeId: integer("product_type_id").notNull(),
  sizeId: integer("size_id").notNull(),
  glazingPercentage: decimal("glazing_percentage", { precision: 10, scale: 2 }).notNull(),
  rawMaterialCost: decimal("raw_material_cost", { precision: 10, scale: 2 }).notNull(),
  waterCost: decimal("water_cost", { precision: 10, scale: 2 }).notNull(),
  overheadCost: decimal("overhead_cost", { precision: 10, scale: 2 }).notNull(),
  freightCost: decimal("freight_cost", { precision: 10, scale: 2 }).notNull(),
  subsidyAmount: decimal("subsidy_amount", { precision: 10, scale: 2 }).notNull(),
  totalCostBDT: decimal("total_cost_bdt", { precision: 10, scale: 2 }).notNull(),
  totalCostUSD: decimal("total_cost_usd", { precision: 10, scale: 2 }).notNull(),
  calculationDate: timestamp("calculation_date").notNull().defaultNow(),
});

export const insertCostResultSchema = createInsertSchema(costResults)
  .pick({
    productTypeId: true,
    sizeId: true,
    glazingPercentage: true,
    rawMaterialCost: true,
    waterCost: true,
    overheadCost: true,
    freightCost: true,
    subsidyAmount: true,
    totalCostBDT: true,
    totalCostUSD: true,
  })
  .transform((data) => {
    return Object.entries(data).reduce((acc, [key, value]) => {
      return {
        ...acc,
        [key]: typeof value === 'number' ? String(value) : value
      };
    }, {});
  });

export type InsertCostResult = z.infer<typeof insertCostResultSchema>;
export type CostResult = typeof costResults.$inferSelect;

// Input interfaces for API
export const costCalculationInputSchema = z.object({
  productType: z.string(),
  glazingPercentage: z.number(),
  size: z.string(),
});

export type CostCalculationInput = z.infer<typeof costCalculationInputSchema>;
